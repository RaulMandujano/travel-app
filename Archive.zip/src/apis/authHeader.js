export default {
    'X-RapidAPI-Host': 'airbnb13.p.rapidapi.com',
    'X-RapidAPI-Key': 'b2676f4bacmshf024e52eb9e1defp1b229djsn7b29df711424'
}